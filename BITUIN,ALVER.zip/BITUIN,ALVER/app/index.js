import React from "react";
import { View, Text, TextInput, TouchableOpacity, StyleSheet, ImageBackground } from "react-native";
import { useForm, Controller } from "react-hook-form";

const myStyle = StyleSheet.create({
 container: {
 flex: 1,
 justifyContent: "center",
 alignItems: "center",
 padding: 20,
 },
 headerText: {
 fontSize: 24,
 fontWeight: "bold",
 marginBottom: 20,
 color: "white",
 fontFamily: "Impact San-serif", // Set font for header text
 },
 inputContainer: {
 marginBottom: 5,
 width: "100%",
 },
 labelText: {
 fontSize: 16,
 fontWeight: "bold",
 marginBottom: 5,
 color: "white",
 },
 input: {
 backgroundColor: "transparent", // Set input background to transparent
 padding: 10,
 borderRadius: 5,
 width: "100%",
 borderWidth: 1,
 borderColor: "#FFFFFF",
 color: "#FFFFFF", // Set text color to white
 fontFamily: "Impact San-serif", // Set font for input text
 },
 button: {
 backgroundColor: "#FFFFFF",
 padding: 15,
 borderRadius: 5,
 width: "100%",
 alignItems: "center",
 },
 buttonText: {
 color: "black",
 fontSize: 18,
 },
 errorText: {
 color: "red",
 fontFamily: "Impact San-serif", // Set font for error text
 fontSize: 14,
 },
});

export default function Home() {
 const { control, handleSubmit, formState: { errors } } = useForm({
 defaultValues: {
 email: '',
 password: '',
 }
 });

 const onSubmit = data => {
 console.log(data);
 };

 return (
 <ImageBackground
 source={{ uri: 'https://cutewallpaper.org/23/android-palm-tree-wallpaper/431530649.https://images.unsplash.com/photo-1608541737042-87a12275d313?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxleHBsb3JlLWZlZWR8Mnx8fGVufDB8fHx8fA%3D%3D&w=1000&q=80jpghttps://www.google.com/url?sa=i&url=https%3A%2F%2Funsplash.com%2Fwallpapers%2Fcompanies%2Fnike&psig=AOvVaw2Brou_0RGp0UpicHsvZOi0&ust=1697523311292000&source=images&cd=vfe&opi=89978449&ved=0CBEQjRxqFwoTCNDX1_32-YEDFQAAAAAdAAAAABAD' }}
 style={myStyle.container}
 >
 <View style={myStyle.container}>
 <Text style={myStyle.headerText}>Login your account</Text>

 <View style={myStyle.inputContainer}>
 <Text style={myStyle.labelText}>Email:</Text>
 <Controller
 control={control}
 rules={{
 required: true,
 }}
 render={({ field: { onChange, onBlur, value } }) => (
 <TextInput
 placeholder="Enter your Email"
 onBlur={onBlur}
 onChangeText={onChange}
 value={value}
 style={myStyle.input}
 keyboardType="email-address"
 />
 )}
 name="email"
 />
 {errors.email && <Text style={myStyle.errorText}>This is required.</Text>}
 </View>

 <View style={myStyle.inputContainer}>
 <Text style={myStyle.labelText}>Password:</Text>
 <Controller
 control={control}
 rules={{
 required: true,
 }}
 render={({ field: { onChange, onBlur, value } }) => (
 <TextInput
 placeholder="Enter password"
 onBlur={onBlur}
 onChangeText={onChange}
 value={value}
 style={myStyle.input}
 secureTextEntry={true}
 />
 )}
 name="password"
 />
 {errors.password && <Text style={myStyle.errorText}>This is required.</Text>}
 </View>

 <TouchableOpacity style={myStyle.button} onPress={handleSubmit(onSubmit)}>
 <Text style={myStyle.buttonText}>Sign In</Text>
 </TouchableOpacity>
 </View>
 </ImageBackground>
 );
}
